str(country_data)
summary(country_data)
install.packages("tidyverse")
install.packages("ggplot2")
install.packages("ggmap")
install.packages("lubridate")
install.packages("sf")
library("tidyverse")
library("ggplot2")
library("ggmap")
library("lubridate")
library("sf")
countries <- c("Ireland", "Comoros", "Gabon", "Tunisia", "Jordan", "Antigua and Barbuda", "Aruba", "Sint Maarten", "Northern Mariana Islands", "Ecuador")
filtered_data <- country_data 

world <- map_data("world")
world_data <- filtered_data %>%
 group_by(location) %>%
  summarize(total_cases = sum(total_cases, na.rm = TRUE),
  total_deaths = sum(total_deaths, na.rm = TRUE))
world_map_data <- world %>%
  left_join(world_data, by = c("region" = "location"))
ggplot(world_map_data, aes(long, lat, group = group)) +
geom_polygon(aes(fill = total_cases), color = "white") +
scale_fill_continuous(low = "yellow", high = "red", na.value = "grey") +              
labs(title = "Map of COVID-19 Cases",  
fill = "Total Cases") +
  theme_minimal()

bar_data <- filtered_data %>%
group_by(location) %>%
summarize(total_cases = sum(total_cases, na.rm = TRUE))
ggplot(bar_data, aes(x = reorder(location, -total_cases), y = total_cases)) +
geom_bar(stat = "identity", fill = "blue") +
labs(title = "yotal COVID-19 cases by country", 
x = "country",
y = "Total Cases") +
theme_minimal() +
coord_flip()  


scatter_data <- filtered_data %>%
group_by(location) %>%
summarize(total_cases = sum(total_cases, na.rm = TRUE),  
total_deaths = sum(total_deaths, na.rm = TRUE))
ggplot(scatter_data, aes(x = total_cases, y = total_deaths)) +
geom_point(color = "green") +  
geom_smooth(method = "lm", color = "black") +  
labs(title = "Scatterplot of total cases vs. total deaths",  
x = "Total Cases",     
y = "Total Deaths") +
theme_minimal()


filtered_data$date <- as.Date(filtered_data$date, format = "%Y-%m-%d")
time_series_data <- filtered_data %>%
group_by(date, location) %>%
summarize(new_cases = sum(new_cases, na.rm = TRUE))
ggplot(time_series_data, aes(x = date, y = new_cases, color = location)) +
  geom_line() +
labs(title = "daily COVID-19 cases over time",
x = "date",
y = "new cases") +
theme_minimal()
     
     